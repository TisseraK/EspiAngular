export interface ProfileUpdateInterface {
  first_name: string;
  last_name: string;
}
