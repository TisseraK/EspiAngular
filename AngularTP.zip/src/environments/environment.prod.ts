export const environment = {
  api: 'https://api-teaching.wecolearn.com',
  production: true
};
